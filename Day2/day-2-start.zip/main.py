#Data Types
print("Hello" [4])