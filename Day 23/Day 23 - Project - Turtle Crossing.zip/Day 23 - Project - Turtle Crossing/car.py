import random
from turtle import Turtle


class Car(Turtle):
    def __init__(self, y_pos, color, level):
        super().__init__()
        self.hideturtle()
        self.penup()
        self.goto(350, y_pos)
        self.setheading(180)
        self.shape("square")
        self.shapesize(stretch_wid=0.75, stretch_len=2)
        self.color(color)
        self.showturtle()
        self.level = level

    def move(self):
        speed = 20 + (2 * self.level)
        self.forward(speed)
