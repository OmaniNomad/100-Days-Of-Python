from turtle import Turtle

ALIGNMENT = "Center"
FONT = ("Courier", 14, "normal")


class Scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.penup()
        self.hideturtle()
        self.pencolor("black")
        self.goto(-230, 260)
        self.score = 0
        self.write(arg=f"SCORE: {self.score}", align=ALIGNMENT, font=FONT)

    def add_score(self):
        self.clear()
        self.write(arg=f"SCORE: {self.score}", align=ALIGNMENT, font=FONT)

    def game_over(self):
        self.goto(0, 0)
        self.write(arg="GAME OVER", align=ALIGNMENT, font=FONT)