from turtle import Screen
from player import *
from car import *
from scoreboard import *
import random
import time

# Game setup
GAME_SPEED = 0.1
current_level = 0
colors = ("red", "blue", "green", "yellow", "purple", "brown", "orange", "pink")
cars = []
count = 0

# Class creation
screen = Screen()
player = Player()
scoreboard = Scoreboard()

# Screen setup
screen.setup(width=600, height=600)
screen.bgcolor("white")
screen.tracer(0)

# Starting game
game_is_on = True
while game_is_on:
    while player.ycor() != 300:
        if not game_is_on:
            break
        random_color = random.choice(colors)
        random_y = random.randrange(-260, 261, 20)
        count += 1
        if count == 5:
            new_car = Car(y_pos=random_y, color=random_color, level=current_level)
            cars.append(new_car)
            count = 0
        screen.onkeypress(fun=player.move, key="w")
        for car in cars:
            if car.xcor() != -320:
                car.move()
            if car.distance(player) < 22:
                scoreboard.game_over()
                game_is_on = False
                break
        screen.update()
        time.sleep(GAME_SPEED)
        # if player gets to top of screen, add 1 to current level and reset turtle position
        screen.listen()

    if not game_is_on:
        break
    player.hideturtle()
    player.goto(0, -280)
    current_level += 1
    scoreboard.score += 1
    scoreboard.add_score()
    player.showturtle()

screen.exitonclick()
