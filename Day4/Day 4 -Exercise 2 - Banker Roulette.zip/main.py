import random

# 🚨 Don't change the code below 👇
test_seed = int(input("Create a seed number: "))
random.seed(test_seed)

# Split string method
names_string = input("Give me everybody's names, separated by a comma. ")
names = names_string.split(", ")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇

#len will count items in the list. -1 since list starts at 0.
x = len(names) - 1

random_int = random.randint(0,x)

random_name = names[random_int]

print(f"{random_name} is going to buy the meal today!")