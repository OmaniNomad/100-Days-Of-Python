from turtle import Turtle, Screen
import random

# setup
turtle_count = 0
available_colors = ("red", "blue", "green", "orange", "silver", "purple")
screen = Screen()
screen.setup(width=500, height=400)
all_turtles = []

# ask user how many turtles should be created
while turtle_count < 2 or turtle_count > 6:
    turtle_count = int(screen.textinput(title="Racing turtles", prompt="How many turtles are racing? "
                                                                       "Choose between 2-6: "))

# figuring out x and y for each turtle
x = -230
dist_btw_turtles = 300 / turtle_count
y = -200 + dist_btw_turtles

for i in range(turtle_count):
    new_turtle = Turtle(shape="turtle")
    new_turtle.color(available_colors[i])
    new_turtle.penup()
    new_turtle.goto(x, y)
    y += dist_btw_turtles
    all_turtles.append(new_turtle)

# asking user which turtle they think will win
user_bet = screen.textinput(title="Make your bet", prompt="Which turtle will win the race? "
                                                          "Enter a color from those on screen: ").lower()

# check if bets are completed
if user_bet:
    start_race = True

# begin race
while start_race:

    for turtle in all_turtles:
        if turtle.xcor() > 230:
            start_race = False
            winning_color = turtle.pencolor()
            if winning_color == user_bet:
                print(f"Your {winning_color} turtle won the race! You win! :)")
                break
            print(f"Your {user_bet} turtle didn't win the race. You lose. :(")
            break
        rand_dist = random.randint(0, 10)
        turtle.forward(rand_dist)
# if any turtle crosses finish line at 490th pixel, end game and store turtle winner


# inform user whether they won or lost


screen.exitonclick()
