

  #TODO-1: Create a function called 'encrypt' that takes the 'text' and 'shift' as inputs.



      #TODO-2: Inside the 'encrypt' function, shift each letter of the 'text' forwards in the alphabet by the shift amount and print the final text.  
      #e.g. 
      #plain_text = "hello"
      #shift = 5
      #cipher_text = "mjqqt"
      #print output: "The encoded text is mjqqt"

      ##HINT: How do you get the index of an item in a list:
      #https://stackoverflow.com/questions/176918/finding-the-index-of-an-item-in-a-list

      ##🐛Bug alert: What happens if you try to encode the word 'civilization'?🐛

  #TODO-3: Call the encrypt function and pass in the user inputs. You should be able to test the code and encrypt a message. 

alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

letter_count = len(alphabet)

while True:

  def caesar(direction, plain_text, shift_amount):
    final_message = ""
    if direction == "decode":
      shift_amount *= -1
    for letter in plain_text:
      if letter in alphabet:
        position = alphabet.index(letter)
        new_position = position + shift_amount
        if new_position > letter_count:
          new_position -= letter_count
        elif new_position < 0:
          new_position += letter_count
        final_message += alphabet[new_position]
      else:
        final_message += letter
    print(f"The {direction}d text is: {final_message}")
  
  while True:
    direction = input("Type 'encode' to encrypt, or type 'decode' to decrypt:\n")
        
    if direction in ("encode", "decode"):
      text = input("Type your message:\n").lower()
      while True:
        shift = int(input("Type the shift number:\n"))
        if shift in (0, 25):
          break
        else:
          print("Invalid input. Choose a number between 0 and 25")
      plain_text = text
      shift_amount = shift
      caesar(direction, plain_text, shift_amount)
      break
    print("Invalid input.")

  while True:
    go_again = input("Type 'yes' if you want to go again. Otherwise type 'no'\n").lower()

    if go_again in ("yes", "no"):
      break
    print("invalid input")

  if go_again == "no":
    print("Goodbye!")
    break