#Write your code below this line 👇
print("What is your name?")
provided_name = input()
print(len(provided_name))








