import requests
import datetime as dt




LOCAL_UTC_OFFSET = 4
muscat_lat = 23.605222
muscat_long = 58.359915


parameters = {
    "lat": muscat_lat,
    "lng": muscat_long,
    "formatted": 0
}

response = requests.get(url="https://api.sunrise-sunset.org/json", params=parameters)
response.raise_for_status()
data = response.json()

sunrise = int(data["results"]["sunrise"].split("T")[1].split(":")[0])
sunset = int(data["results"]["sunset"].split("T")[1].split(":")[0])

sunrise_local = utc_to_local(sunrise)
sunset_local = utc_to_local(sunset)
print(sunrise_local)
print(sunset_local)

current_time = dt.datetime.now()
print(current_time.hour)
