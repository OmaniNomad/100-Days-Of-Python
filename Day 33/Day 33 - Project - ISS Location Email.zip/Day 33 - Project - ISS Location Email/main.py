import requests
import datetime as dt
import smtplib
import time

LOCAL_UTC_OFFSET = 4
MUSCAT_LAT = 23.614328
MUSCAT_LNG = 58.545284
iss_lat = 0
iss_lng = 0


def utc_to_local(utc_hour):
    utc_hour += LOCAL_UTC_OFFSET
    if LOCAL_UTC_OFFSET > 0:
        if utc_hour > 23:
            utc_hour -= 24
    elif LOCAL_UTC_OFFSET < 0:
        if utc_hour < 0:
            utc_hour += 24
    return utc_hour


def iss_check():
    # Requesting current ISS location
    response = requests.get(url="http://api.open-notify.org/iss-now.json")
    response.raise_for_status()
    data = response.json()
    global iss_lat, iss_lng
    iss_lat = float(data["iss_position"]["latitude"])
    iss_lng = float(data["iss_position"]["longitude"])
    if MUSCAT_LAT - 5 <= iss_lat <= MUSCAT_LAT + 5 and MUSCAT_LNG - 5 <= iss_lng <= MUSCAT_LNG + 5:
        return True


def night_check():
    # Finding current time, sunrise and sunset for my location (Muscat)
    mct_time = dt.datetime.now().hour

    parameters = {
        "lat": MUSCAT_LAT,
        "lng": MUSCAT_LNG,
        "formatted": 0,
    }
    response = requests.get("https://api.sunrise-sunset.org/json", params=parameters)
    response.raise_for_status()
    data = response.json()
    sunrise_utc = int(data["results"]["sunrise"].split("T")[1].split(":")[0])
    sunset_utc = int(data["results"]["sunset"].split("T")[1].split(":")[0])
    sunrise_local = utc_to_local(sunrise_utc)
    sunset_local = utc_to_local(sunset_utc)

    if sunset_local <= mct_time <= sunrise_local:
        return True


def send_email():
    connection = smtplib.SMTP("smtp.gmail.com")
    connection.starttls()
    connection.login(user="smtp100days@gmail.com", password="fighter1q1")
    connection.sendmail(from_addr="smtp100days@gmail.com", to_addrs="smtp100days@gmail.com",
                        msg=f"Subject:ISS Overhead!\n\nLook up! ISS is passing over you! Current ISS coordinates are:\n"
                            f"LAT:{iss_lat}\nLNG:{iss_lng}")
    connection.close()


# Comparing LAT and LNG of ISS to Muscat within +5 or -5 deg and checking if currently night in Muscat
# If both true, sending email to myself to look up
# Running code every 60 seconds
while True:
    time.sleep(60)
    print("awake")
    if iss_check() and night_check():
        send_email()
