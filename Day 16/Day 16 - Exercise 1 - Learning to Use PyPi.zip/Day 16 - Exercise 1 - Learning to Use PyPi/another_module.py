another_variable = 12

