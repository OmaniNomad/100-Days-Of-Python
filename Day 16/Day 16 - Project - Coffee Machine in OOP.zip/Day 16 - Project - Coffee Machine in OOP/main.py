from menu import Menu
from coffee_machine import CoffeeMachine
from payment_machine import CollectPayment

# class creation
menu = Menu()
money_machine = CollectPayment()
coffee_machine = CoffeeMachine()

# starting coffee machine
machine_is_on = True
while machine_is_on:
    order_name = None

    while order_name is None:
        user_request = input(f"What would you like? {menu.get_items()}: ")
        if user_request == "report":
            coffee_machine.report()
            money_machine.report()
        elif user_request == "off":
            print("Machine turning off.")
            quit()
        else:
            order_name = menu.find_drink(user_request)

    if coffee_machine.resource_check(order_name):
        if money_machine.make_payment(order_name.cost):
            coffee_machine.make_coffee(order_name)
