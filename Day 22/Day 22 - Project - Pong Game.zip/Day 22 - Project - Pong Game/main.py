from turtle import Screen, Turtle
from paddle import Paddle
from ball import Ball
from scoreboard import Scoreboard
import time

# Screen setup
screen = Screen()
screen.setup(width=1000, height=600)
screen.bgcolor("black")
screen.title("Pong game")
screen.tracer(0)

# setting up middle boundary
middle_boundary = Turtle()
middle_boundary.hideturtle()
middle_boundary.goto(0, 300)
middle_boundary.setheading(270)
middle_boundary.color("white")
middle_boundary.pensize(3)
middle_boundary.shape("square")
for _ in range(30):
    middle_boundary.forward(10)
    middle_boundary.penup()
    middle_boundary.forward(10)
    middle_boundary.pendown()

# creating the paddles
l_paddle = Paddle((-480, 0))
r_paddle = Paddle((480, -260))

# creating the ball
ball = Ball()
ball.ball_reset()

# creating the scoreboard
scoreboard = Scoreboard()

# starting the game
game_is_on = True

while game_is_on:

    screen.listen()

    screen.onkeypress(fun=l_paddle.up, key="w")
    screen.onkeypress(fun=l_paddle.down, key="s")
    screen.onkeypress(fun=r_paddle.up, key="o")
    screen.onkeypress(fun=r_paddle.down, key="l")
    screen.onkeypress(fun=ball.move_ball(), key="e")
    # r_paddle.comp_move()

    if ball.ycor() > 280 or ball.ycor() < -280:
        ball.wall_collision()

    if ball.distance(l_paddle) < 50 and ball.xcor() < -460:
        ball.paddle_collision()

    if ball.distance(r_paddle) < 50 and ball.xcor() > 460:
        ball.paddle_collision()

    if ball.xcor() > 500 or ball.xcor() < -500:
        scoreboard.add_point(ball.xcor())
        ball.ball_reset()

    if scoreboard.paddle1_score == 5 or scoreboard.paddle2_score == 5:
        scoreboard.game_over()
        game_is_on = False

    screen.update()

    time.sleep(ball.ball_speed)

screen.exitonclick()
