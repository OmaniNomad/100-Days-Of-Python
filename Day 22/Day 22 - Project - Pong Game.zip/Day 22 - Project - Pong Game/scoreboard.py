from turtle import Turtle

ALIGNMENT = "center"
FONT = ("Courier", 24, "normal")
COLOR = "white"


class Scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.paddle1_score = 0
        self.paddle2_score = 0
        self.hideturtle()
        self.pencolor(COLOR)
        self.penup()
        self.setpos(0, 250)
        self.write(arg=f"{self.paddle1_score}      {self.paddle2_score}", move=False, align=ALIGNMENT, font=FONT)

    def add_point(self, x):
        if x > 500:
            self.paddle1_score += 1
        else:
            self.paddle2_score += 1
        self.clear()
        self.write(arg=f"{self.paddle1_score}      {self.paddle2_score}", move=False, align=ALIGNMENT, font=FONT)

    def game_over(self):
        self.goto(0, 0)
        self.write(arg="GAME OVER", align=ALIGNMENT, font=FONT)
