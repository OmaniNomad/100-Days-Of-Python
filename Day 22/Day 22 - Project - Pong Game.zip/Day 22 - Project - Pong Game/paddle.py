from turtle import Turtle


class Paddle(Turtle):
    def __init__(self, position):
        super().__init__()
        self.color("white")
        self.shape("square")
        self.penup()
        self.shapesize(stretch_wid=0.5, stretch_len=4)
        self.setheading(90)
        self.move_up = True
        self.goto(position)

    def up(self):
        new_y = self.ycor() + 20
        if self.ycor() != 260:
            self.goto(self.xcor(), new_y)

    def down(self):
        new_y = self.ycor() - 20
        if self.ycor() != -260:
            self.goto(self.xcor(), new_y)

# if playing against 2nd player, comment this out, then enable 2nd player controls in main.py by
# uncommenting the "screen.onkeypress" for "r_paddle" and commenting out comp_move()
#     def comp_move(self):
#         if self.ycor() == -260:
#             self.move_up = True
#         elif self.ycor() == 260:
#             self.move_up = False
#
#         if self.move_up:
#             new_y = self.ycor() + 20
#             self.goto(self.xcor(), new_y)
#         else:
#             new_y = self.ycor() - 20
#             self.goto(self.xcor(), new_y)
