from turtle import Turtle
import random


class Ball(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("circle")
        self.color("white")
        self.penup()
        self.ball_speed = 0.08

    def ball_reset(self):
        random_angle_spawn = random.randint(135, 225)
        random_y_spawn = random.randint(-250, 250)
        self.goto(0, random_y_spawn)
        self.setheading(random_angle_spawn)
        self.ball_speed = 0.08

    def move_ball(self):
        self.forward(20)

    def wall_collision(self):
        if 90 < self.heading() < 270:
            angle = 180 - self.heading()
            new_heading = 180 + angle
        else:
            new_heading = 360 - self.heading()
        self.setheading(new_heading)

    def paddle_collision(self):
        if 180 < self.heading() < 360:
            angle = 270 - self.heading()
            new_heading = 270 + angle
            self.ball_speed *= 0.9
        else:
            new_heading = 180 - self.heading()
            self.ball_speed *= 0.9
        self.setheading(new_heading)
