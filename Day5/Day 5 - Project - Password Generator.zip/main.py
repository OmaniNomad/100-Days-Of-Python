#Password Generator Project

#Eazy Level - Order not randomised:
#e.g. 4 letter, 2 symbol, 2 number = JduE&!91

#Hard Level - Order of characters randomised:
#e.g. 4 letter, 2 symbol, 2 number = g^2jk8&P

import random
letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']

print("Welcome to the PyPassword Generator!")
nr_letters= int(input("How many letters would you like in your password?\n")) 
nr_symbols = int(input(f"How many symbols would you like?\n"))
nr_numbers = int(input(f"How many numbers would you like?\n"))

password_length = nr_letters + nr_symbols + nr_numbers
count_letter = 0
count_number = 0
count_symbol = 0
password_list = []

for character in range(password_length):

  refreshing_random_list = []

  if count_letter < nr_letters:
    refreshing_random_list.append("letter")

  if count_number < nr_numbers:
    refreshing_random_list.append("number")

  if count_symbol < nr_symbols:
    refreshing_random_list.append("symbol")

  types_available = len(refreshing_random_list)

  type_choice_num = random.randint(0, types_available - 1)

  type_choice = refreshing_random_list[type_choice_num]

  if type_choice == "letter":
    
      random_letter = random.randint(0,51)
      current_letter_choice = letters[random_letter]
      password_list.append(current_letter_choice)
      count_letter += 1

  elif type_choice == "number":
    
      random_number = random.randint(0,9)
      current_number_choice = numbers[random_number]
      password_list.append(current_number_choice)
      count_number += 1

  elif type_choice == "symbol":
    
      random_symbol = random.randint(0,8)
      current_symbol_choice = symbols[random_symbol]
      password_list.append(current_symbol_choice)
      count_symbol += 1

final_password = ""

for character in password_list:
  final_password += character

print(final_password)