#Write your code below this row 👇

total_even = 0

for even_number in range(0, 101, 2):
    total_even += even_number

print(total_even)