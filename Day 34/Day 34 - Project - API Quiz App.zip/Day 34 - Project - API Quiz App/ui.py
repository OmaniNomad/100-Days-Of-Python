from tkinter import *
from quiz_brain import QuizBrain

THEME_COLOR = "#375362"
CANVAS_FONT = ("Arial", 18, "normal")
SCORE_FONT = ("Arial", 14, "bold")


class QuizInterface:
    def __init__(self, quiz_brain: QuizBrain):
        self.quiz = quiz_brain
        self.window = Tk()
        self.window.title("Quizzler")
        self.window.config(bg=THEME_COLOR, pady=20, padx=20)

        self.canvas = Canvas(width=300, height=250, bg="white")
        self.canvas.grid(column=0, row=1, columnspan=2, padx=20, pady=20)
        self.question_text = self.canvas.create_text(150,
                                                     140,
                                                     width=280,
                                                     font=CANVAS_FONT,
                                                     justify="left",
                                                     anchor="center",
                                                     text="Question goes here.")

        self.score_label = Label(text=f"Score: ",
                                 bg=THEME_COLOR,
                                 font=SCORE_FONT,
                                 fg="white")
        self.score_label.grid(column=1, row=0, padx=20, pady=20)

        true_img = PhotoImage(file="true.png")
        self.true_button = Button(command=self.true,
                                  image=true_img,
                                  padx=20,
                                  pady=20,
                                  highlightthickness=0,
                                  highlightcolor=THEME_COLOR)
        self.true_button.grid(column=0, row=2)

        false_img = PhotoImage(file="false.png")
        self.false_button = Button(command=self.false,
                                   image=false_img,
                                   padx=20,
                                   pady=20,
                                   highlightthickness=0,
                                   highlightcolor=THEME_COLOR)
        self.false_button.grid(column=1, row=2)

        self.get_next_question()

        self.window.mainloop()

    def get_next_question(self):
        self.canvas.config(bg="white")
        self.score_label.config(text=f"Score: {self.quiz.score}/{self.quiz.question_number}")
        if self.quiz.still_has_questions():
            q_text = self.quiz.next_question()
            self.canvas.itemconfig(self.question_text, text=q_text)
        else:
            self.canvas.itemconfig(self.question_text, text="You've completed the quiz!")
            self.true_button.config(state="disabled")
            self.false_button.config(state="disabled")

    def true(self):
        self.feedback(self.quiz.check_answer("true"))

    def false(self):
        self.feedback(self.quiz.check_answer("false"))

    def feedback(self, is_right):
        if is_right:
            self.canvas.config(bg="green")
        else:
            self.canvas.config(bg="red")
        self.window.after(1000, self.get_next_question)
