import datetime as dt
import random
import smtplib

# Random quote from the txt file
with open(file="quotes.txt", mode="r") as file:
    quotes = file.readlines()
    quotes_list = list(quotes)
    random_quote = random.choice(quotes_list)

# identifying the day of the week
week_day = dt.datetime.now().weekday()

if week_day == 5:

    connection = smtplib.SMTP("smtp.gmail.com")
    connection.starttls()
    connection.login(user="smtp100days@gmail.com", password="fighter1q1")
    connection.sendmail(from_addr="smtp100days@gmail.com", to_addrs="smtp_100days@yahoo.com",
                        msg=f"Subject:Motivational Quote\n\nHere is your motivational quote: {random_quote}")
    connection.close()
