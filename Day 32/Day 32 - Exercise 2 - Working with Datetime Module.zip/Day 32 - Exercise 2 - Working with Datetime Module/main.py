import datetime as dt

now = dt.datetime.now()
year = now.year
day_of_week = now.weekday()
print(now)
print(year)
print(day_of_week)


date_of_birth = dt.datetime(year=1992, month=2, day=21)
print(date_of_birth)
