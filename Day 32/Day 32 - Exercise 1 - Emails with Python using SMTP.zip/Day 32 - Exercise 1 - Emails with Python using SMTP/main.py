import smtplib
# ---------------------------------------------------
# Using SMTP to send emails between GMAIL and YAHOO
# ---------------------------------------------------
# my_gmail = "smtp100days@gmail.com"
# gmail_password = "fighter1q1"
# my_yahoo = "smtp_100days@yahoo.com"
# yahoo_password = "grrwvkkpbbkvyjyk"

# # Sending from GMAIL
# connection = smtplib.SMTP("smtp.gmail.com")
# connection.starttls()
# connection.login(user=my_gmail, password=gmail_password)
# connection.sendmail(from_addr=my_gmail,
#                     to_addrs=my_yahoo,
#                     msg="Subject:Testing SMTP\n\n"
#                         "Hello World!")
# connection.close()

# # Sending from YAHOO
# connection = smtplib.SMTP("smtp.mail.yahoo.com")
# connection.starttls()
# connection.login(user=my_yahoo, password=yahoo_password)
# connection.sendmail(from_addr=my_yahoo,
#                     to_addrs=my_gmail,
#                     msg="Subject:Testing SMTP\n\n"
#                         "Hello World!")
# connection.close()
