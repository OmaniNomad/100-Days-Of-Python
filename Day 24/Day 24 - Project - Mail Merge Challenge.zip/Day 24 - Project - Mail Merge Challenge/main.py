# TODO: Create a letter using starting_letter.txt
# for each name in invited_names.txt
# Replace the [name] placeholder with the actual name.
# Save the letters in the folder "ReadyToSend".

# Stripping each name in the source file and adding them to a new list
with open("./Input/Names/invited_names.txt", mode="r") as invited_names:
    invited_list = invited_names.readlines()

# creating the letter from the source file
with open("./Input/Letters/starting_letter.txt", mode="r") as starting_letter:
    letter = starting_letter.read()

# creating a new letter for each name in the list, adding the name to it, and saving as a new file
for name in invited_list:
    final_name = name.strip()
    with open(f"./Output/ReadyToSend/letter_for_{final_name}.txt", mode="w") as stored_letter:
        stored_letter.write(letter.replace("[name]", final_name))
