from data import question_data
from question_model import Question
from quiz_brain import QuizBrain

playing = True
question_bank = []

for i in range(len(question_data)):
    question_bank.append(Question(text=question_data[i]["question"], answer=question_data[i]["correct_answer"]))

quiz = QuizBrain(question_bank)

while quiz.still_has_questions():
    quiz.next_question()

print(f"You've completed the quiz. Your final score was: {quiz.score}/{len(question_bank)}")
