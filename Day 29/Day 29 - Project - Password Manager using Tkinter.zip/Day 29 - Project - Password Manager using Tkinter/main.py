from tkinter import *
from tkinter import messagebox
import random
import characters
import pyperclip


# ---------------------------- PASSWORD GENERATOR ------------------------------- #
def generate_password():
    nr_letters = random.randint(8, 10)
    nr_symbols = random.randint(2, 4)
    nr_numbers = random.randint(2, 4)

    password_list = []

    [password_list.append(random.choice(characters.letters)) for _ in range(nr_letters)]
    [password_list.append(random.choice(characters.symbols)) for _ in range(nr_symbols)]
    [password_list.append(random.choice(characters.numbers)) for _ in range(nr_numbers)]
    random.shuffle(password_list)
    password = ''.join(char for char in password_list)
    password_field.delete(0, END)
    password_field.insert(END, string=password)
    pyperclip.copy(password)


# ---------------------------- SAVE PASSWORD ------------------------------- #
def add():
    website = website_field.get()
    email = email_field.get()
    password = password_field.get()

    if website == "" or email == "username@email.com" or password == "":
        messagebox.showerror(title="Missing Details", message="Please make sure you've filled all of the fields before "
                                                              "pressing 'Add'.")

    else:
        is_ok = messagebox.askokcancel(title=website, message=f"These are the details entered: \n"
                                       f"Email: {email} \nPassword: {password}")

        if is_ok:
            with open(file="passwords.txt", mode="a") as file:
                file.write(f"{website} | {email} | {password}\n")
            website_field.delete(0, END)
            email_field.delete(0, END)
            email_field.insert(0, "username@email.com")
            password_field.delete(0, END)

# ---------------------------- UI SETUP ------------------------------- #


# window
window = Tk()
window.title("Password Manager")
# window.minsize(width=300, height=300)
window.config(padx=20, pady=20)


# canvas
canvas = Canvas(width=200, height=200)
lock_image = PhotoImage(file="logo.png")
canvas.create_image(100, 100, image=lock_image)
canvas.grid(column=1, row=0)


# website label and field
website_label = Label(text="Website:", font=("Arial", 12, "normal"))
website_label.grid(column=0, row=1, sticky="e", padx=5, pady=5)

website_field = Entry(width=35, font=("Arial", 12, "normal"))
website_field.grid(column=1, row=1, columnspan=2, sticky="e")
website_field.focus()


# email/username label and field
username_label = Label(text="Email/Username:", font=("Arial", 12, "normal"))
username_label.grid(column=0, row=2, sticky="e", padx=5, pady=5)

email_field = Entry(width=35, font=("Arial", 12, "normal"))
email_field.insert(0, string="username@email.com")
email_field.grid(column=1, row=2, columnspan=2, sticky="e")


# password label and field
password_label = Label(text="Password:", font=("Arial", 12, "normal"))
password_label.grid(column=0, row=3, sticky="e", padx=5, pady=5)

password_field = Entry(width=26, font=("Arial", 12, "normal"))
password_field.grid(column=1, row=3, sticky="e")


# generate password button
generate_button = Button(text="Generate", width=7, command=generate_password, font=("Arial", 12, "normal"))
generate_button.grid(column=2, row=3, sticky="e", pady=5)


# add button
add_button = Button(text="Add", command=add, width=35, font=("Arial", 12, "normal"))
add_button.grid(column=1, row=4, columnspan=2, sticky="w", pady=5)


window.mainloop()
