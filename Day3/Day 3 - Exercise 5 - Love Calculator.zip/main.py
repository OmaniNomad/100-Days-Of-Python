# 🚨 Don't change the code below 👇
print("Welcome to the Love Calculator!")
name1 = input("What is your name? \n")
name2 = input("What is their name? \n")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇

# merge names into both_names function
both_names = name1+name2

#lower case all names
both_names_lower = both_names.lower()

#count(true) as int
t = both_names_lower.count("t")

r = both_names_lower.count("r")

u = both_names_lower.count("u")

e = both_names_lower.count("e")

total_true = t + r + u + e


#count(love) as int
l = both_names_lower.count("l")

o = both_names_lower.count("o")

v = both_names_lower.count("v")

e = both_names_lower.count("e")

total_love = l + o + v + e


#make 2 digit number by joining and converting to str
total_as_string = str(total_true) + str(total_love)

#make 2 digit number by joining str and turning it back into an integer
score = int(total_as_string)

if score < 10 or score > 90:
    print(f"Your score is {score}, you go together like coke and mentos.")

elif score >= 40 and score <= 50:
    print(f"Your score is {score}, you are alright together.")

else:
    print(f"Your score is {score}.")