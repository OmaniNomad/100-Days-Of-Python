from replit import clear
import art

#HINT: You can call clear() to clear the output in the console.

print(art.logo)

print("Welcome to the secret auction program.")

auction_list = {}

while True:
  user_name = input("What is your name? ")
  user_bid = float(input("What's your bid? $"))

  auction_list[user_name] = user_bid
  
  while True:
    new_bidder = input("Are there any other bidders? Type 'yes' or 'no'.\n").lower()

    if new_bidder in ("yes", "no"):
      break

  if new_bidder == "yes":
    clear()
  
  else:
    break

highest_bid = 0
highest_user = ""
matching_bid = 0
matching_user = ""

for name in auction_list:
  
  if auction_list[name] > highest_bid:

    highest_bid = auction_list[name]
    highest_user = name

  elif auction_list[name] == highest_bid:
    matching_bid = auction_list[name]
    matching_user = name

if matching_bid == highest_bid:
  print(f"{highest_user} and {matching_user} both win with a bid of ${highest_bid}. They must fight to the death to determine a final winner..")

else:
  print(f"The winner is {highest_user} with a bid of ${highest_bid}")

print(auction_list)