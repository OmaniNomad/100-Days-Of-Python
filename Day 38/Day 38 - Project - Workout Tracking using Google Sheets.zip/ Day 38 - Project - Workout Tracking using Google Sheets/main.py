import requests
import datetime as dt

# ----- NUTRITIONIX API ----- #

NUTRITIONIX_EXERCISE_ENDPOINT = "https://trackapi.nutritionix.com/v2/natural/exercise"
NUTRITIONIX_SHEETY_APP_ID = "5b795b0f"
NUTRITIONIX_SHEETY_API_KEY = "afd2389222ee1ebf63daed896c9ce98f"

exercises = ""

while True:
    exercise_input = input("What exercise would you like to log? "
                           "(Example: run 3 km) When done inputting exercises type 'stop': ")
    if exercise_input == 'stop':
        break
    exercises += f"{exercise_input}\n"

NUTRITIONIX_HEADER = {
    "x-app-id": NUTRITIONIX_SHEETY_APP_ID,
    "x-app-key": NUTRITIONIX_SHEETY_API_KEY,
    "Content-Type": "application/json",
}

nutritionix_body = {
    "query": exercises,
    "gender": "male",
    "weight_kg": 111,
    "height_cm": 178,
    "age": 32
}

nutritionix_response = requests.post(url=NUTRITIONIX_EXERCISE_ENDPOINT,
                                     headers=NUTRITIONIX_HEADER,
                                     json=nutritionix_body)
nutritionix_response.raise_for_status()

workouts = []

for exercise in nutritionix_response.json()["exercises"]:
    workouts.append([exercise["name"], exercise["duration_min"], exercise["nf_calories"]])

# ----- DATE AND TIME ----- #

today = dt.datetime.today()
date = today.strftime("%d/%m/%Y")
time = today.strftime("%H:%M:%S")

# ----- SHEETY API ----- #

SHEETY_URL = "https://api.sheety.co/c1d3bf235a686575716541db6f7107e9/myWorkouts/workouts"

SHEETY_HEADER = {
    "Authorization": "Basic NWI3OTViMGY6YWZkMjM4OTIyMmVlMWViZjYzZGFlZDg5NmM5Y2U5OGY="
}

for workout in workouts:
    sheety_body = {
      "workout": {
          "date": date,
          "time": time,
          "exercise": workout[0],
          "duration": workout[1],
          "calories": workout[2],
      }
    }
    sheety_response = requests.post(url=SHEETY_URL,
                                    headers=SHEETY_HEADER,
                                    json=sheety_body)
    sheety_response.raise_for_status()
    print(sheety_response.text)
