from tkinter import *

# ---------------------------- CONSTANTS ------------------------------- #
PINK = "#e2979c"
RED = "#e7305b"
GREEN = "#9bdeac"
YELLOW = "#f7f5dd"
FONT_NAME = "Courier"
WORK_MIN = 25
SHORT_BREAK_MIN = 5
LONG_BREAK_MIN = 20
current_turn = 0
timer = None

# ---------------------------- TIMER RESET ------------------------------- #


def reset_timer():
    window.after_cancel(timer)
    canvas.itemconfig(timer_text, text="00:00")
    timer_label.config(text="Timer", fg=GREEN)
    tick_label.config(text="")
    global current_turn
    current_turn = 0

# ---------------------------- TIMER MECHANISM ------------------------------- #


def start_timer():
    global current_turn
    current_turn += 1
    # work_sec = WORK_MIN * 60
    # short_break_sec = SHORT_BREAK_MIN * 60
    # long_break_sec = LONG_BREAK_MIN * 60
    work_sec = 5
    short_break_sec = 5
    long_break_sec = 5

    if current_turn % 8 == 0:
        timer_label.config(text="Long Break", fg=RED)
        countdown(long_break_sec)
    elif current_turn % 2 == 0:
        timer_label.config(text="Short Break", fg=PINK)
        countdown(short_break_sec)
    else:
        timer_label.config(text="Work", fg=GREEN)
        countdown(work_sec)

# ---------------------------- COUNTDOWN MECHANISM ------------------------------- #


def countdown(count):
    minutes = count // 60
    seconds = count % 60
    if minutes == 0 or minutes < 10:
        minutes = f"0{minutes}"
    if seconds == 0 or seconds < 10:
        seconds = f"0{seconds}"

    canvas.itemconfig(timer_text, text=f"{minutes}:{seconds}")
    if count > 0:
        global timer
        timer = window.after(1000, countdown, count - 1)
    else:
        if current_turn % 2 == 0:
            ticks = ""
            for _ in range(current_turn // 2):
                ticks += "✔"
            tick_label.config(text=ticks)
        start_timer()

# ---------------------------- UI SETUP ------------------------------- #

# setting up window


window = Tk()
window.title("Pomodoro Timer")
window.minsize(height=200, width=200)
window.config(pady=50, padx=100, bg=YELLOW)

# setting up canvas
canvas = Canvas(width=200, height=224, bg=YELLOW, highlightthickness=0)
tomato_image = PhotoImage(file="tomato.png")
canvas.create_image(100, 112, image=tomato_image)
canvas.grid(column=1, row=1)
timer_text = canvas.create_text(100, 135, text="00:00", fill="white", font=(FONT_NAME, 24, "bold"))

# setting up title label
timer_label = Label(fg=GREEN, bg=YELLOW, text="Timer", font=(FONT_NAME, 48, "bold"))
timer_label.grid(column=1, row=0)

# setting up tick label
tick_label = Label(fg=GREEN, bg=YELLOW, text="", font=(FONT_NAME, 18, "bold"))
tick_label.grid(column=1, row=3)

# setting up start button
start_button = Button(text="Start", bg=YELLOW, command=start_timer, font=(FONT_NAME, 12, "bold"))
start_button.grid(column=0, row=2)

# setting up reset button
start_button = Button(text="Reset", bg=YELLOW, command=reset_timer, font=(FONT_NAME, 12, "bold"))
start_button.grid(column=2, row=2)

window.mainloop()
