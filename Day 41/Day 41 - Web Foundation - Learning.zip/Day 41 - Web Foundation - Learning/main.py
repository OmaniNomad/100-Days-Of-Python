# ----------------------------------------- #
# How does the internet work?
# ----------------------------------------- #

# The internet is just a network of cables connecting clients to servers worldwide.

# A client makes a request (ex: google.com) to ISP who relays it to a DNS server. The DNS server looks up
# the IP address stored in its database that is related to the client's request. The ip address is shared
# with the client via the ISP. The client then sends a direct request to the address through the ISP via
# the internet backbone which is made up of huge cables running both over land and underwater. The server
# located at that address will receive the request, read the message, and send back the information
# requested by the client. (ex: request to visit google.com, server sends back the Google landing page)

# ----------------------------------------- #
# How do websites actually work?
# ----------------------------------------- #

# In order to access a webpage, we use browsers. These browsers are software that allow us to look up an
# ip address of a website and be able to receive data from the server that the browser can render into
# a website that can be seen and used. The data received from the server usually consists of 3 types of
# files: HTML, CSS, and Javascript. The three files have very different jobs:
# HTML is responsible for building the structure of the website, like a builder building walls in a house.
# CSS is responsible for the style of the website, like a painter painting a house.
# Javascript is responsible for the functionality or behaviour of the website, like an electrician wiring
# a house or a plumber installing pipes.
# Taking google landing page as an example, once we receive these files from the server, the HTML provides
# the structure of the website. Namely, the logo image, two buttons and a text box. The CSS file will modify
# the appearance of all the components. The Javascript file gives the website functionality, so you can
# enter text in the text box and click the search button. It will execute the search now.

# ----------------------------------------- #
# HTML
# ----------------------------------------- #

# Headings:

# <h1>THE ADVENTURES OF<br>SHERLOCK HOLMES</h1>

# <h1> This is a tag with an HTML element inside it. The first one is the start tag and the last
# one is the end tag: </h1>. The content goes between the two tags.
# <br> is a line break tag. It is a self-closing tag, meaning it doesn't require an end tag
# <hr> This is a horizontal rule tag. It creates a long line across the page. Also self-closing.

# <hr size="3">
# In the tag above, the 'hr' is the HTML element, while everything after the element are HTML attributes
# use documentation to see which attributes are available for each type of HTML element:
# https://devdocs.io/html/element/hr

# <center>
# This element centers text on screen

# <p>
# This element defines a paragraph

# <em>
# This element defines italicized text

