import random
import turtle
from turtle import Turtle, Screen
t = Turtle()

# timmy.forward(200)
# timmy.right(90)
# timmy.forward(200)
# timmy.right(90)
# timmy.forward(200)
# timmy.right(90)
# timmy.forward(200)
#
# turtle.exitonclick()

# for _ in range(15):
#     t.forward(10)
#     t.penup()
#     t.forward(10)
#     t.pendown()

# ------------------------------------------------
#set the shape's number of sides starting with triangle(3) and ending with decagon(10)

#choose a random color for the shape

#side of length 100. shapes overlaid on each other(aka same starting position and
# top side is equal across all shapes)

# import random
# sides = 3
# turtle.colormode(255)
# for _ in range(10):
#     r = random.randint(1, 255)
#     g = random.randint(1, 255)
#     b = random.randint(1, 255)
#     t.pencolor(r, g, b)
#     for _ in range(sides):
#         t.forward(100)
#         t.right(360 / sides)
#     sides += 1
# turtle.exitonclick()


#------------------------------------------------
#random color for each walk
#larger pen size
#speed up the turtle to draw faster

# t.pensize(8)
# t.speed("fastest")
# direction = (0, 90, 180, 270)
# turtle.colormode(255)
#
# for _ in range(100):
#     r = random.randint(1, 255)
#     g = random.randint(1, 255)
#     b = random.randint(1, 255)
#     t.pencolor(r, g, b)
#     t.right(random.choice(direction))
#     t.forward(40)
# turtle.exitonclick()


#------------------------------------------------
#spirograph
#circles of 100 radius around starting point

# t.speed("fastest")
#
# turtle.colormode(255)
#
# for i in range(60):
#     r = random.randint(1, 255)
#     g = random.randint(1, 255)
#     b = random.randint(1, 255)
#     t.pencolor(r, g, b)
#     t.setheading(i*6)
#     t.circle(100)
# turtle.exitonclick()