import random
import hangman_art
import hangman_words

def current_hangman():

  current_hangman = hangman_art.stages[hangman_count]
  print(f"{current_hangman}\n")
  return

import random

hangman_count = 0

print(f"{hangman_art.logo}\n")
print("\nWelcome to Yousef's hangman!\n")

chosen_word = random.choice(hangman_words.word_list)
chosen_length = len(chosen_word)

secret_word = []
used_letters = []

for letter in chosen_word:
  secret_word.append("_")
print(secret_word)

while secret_word.count("_") != 0 and hangman_count < 6:

  count = 0
  answer_check = 0
  
  user_guess = input("\nPlease guess a letter: ").lower()
  
  if secret_word.count(user_guess) > 0:
    print("\nYou've already guessed that letter and it was right! Please try again with a different letter. Here are the letters you've already guessed:\n")
    print(used_letters)

  elif used_letters.count(user_guess) > 0:
    print("\nYou've already guessed that letter and it was wrong! Please try again with a different letter. Here are the letters you've already guessed:\n")
    print(used_letters)

  else:

    for letter in chosen_word:
      if letter == user_guess:
        secret_word.pop(count)
        secret_word.insert(count, user_guess)
        answer_check = 1
      
      count += 1

    if answer_check == 1:
      print("\nGood choice! That letter is in the word!")
      used_letters.append(user_guess)
      current_hangman()
      print(secret_word)
    
    elif answer_check == 0:
      print("\nSorry, that was wrong. Try again.")
      hangman_count += 1
      used_letters.append(user_guess)
      current_hangman()
      print(secret_word)

if secret_word.count("_") == 0:
  print("\nCongratulations! You figured it out! Feel free to restart and go again.")

elif hangman_count == 6:
  print(f"\nSorry! You've been hung before you could figure out the word. It was '{chosen_word}'. Please try again!")

else:
  print("\nSomething weird has happened. My insides are melting. Please debug me.")
