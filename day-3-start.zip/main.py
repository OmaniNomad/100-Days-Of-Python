print("Welcome to the rollercoaster!")
height = int(input("What is your height in cm? "))
