from bs4 import BeautifulSoup
import requests
import os
import spotipy
from spotipy.oauth2 import SpotifyOAuth
import json

# # --------------------
# # HOT 100 Billboard.com songs
# # --------------------
#
# URL = f'https://web.archive.org/web/20200808001726/https://www.billboard.com/charts/hot-100/{requested_date}/'
#
# requested_date = '2000-08-12'
# # while True:
# #     requested_date = input("Please enter the date you'd like to search for in this format 'YYYY-MM-DD': ")
# #     if len(requested_date) == 10:
# #         break
#
# response = requests.get(URL)
# print(response.raise_for_status())
#
# webpage = response.text
#
# soup = BeautifulSoup(webpage, 'html.parser')
#
# # rank = <span class="chart-element__rank__number">2</span>
# # song = <span class="chart-element__information__song text--truncate color--primary">Bent</span>
# # artist = <span class="chart-element__information__artist text--truncate color--secondary">matchbox twenty</span>
#
# all_ranks = soup.find_all(name='span', class_='chart-element__rank__number')
# final_ranks = []
# for rank in all_ranks:
#     final_ranks.append(rank.get_text())
#
# all_songs = soup.find_all(name='span', class_='chart-element__information__song text--truncate color--primary')
# final_songs = []
# for song in all_songs:
#     final_songs.append(song.get_text())
#
# all_artists = soup.find_all(name='span', class_='chart-element__information__artist text--truncate color--secondary')
# final_artists = []
# for artist in all_artists:
#     final_artists.append(artist.get_text())

# --------------------
# Spotify
# --------------------

SPOTIFY_ENDPOINT = 'https://api.spotify.com'
# SPOTIPY_CLIENT_ID = os.environ['SPOTIPY_CLIENT_ID']
# SPOTIPY_CLIENT_SECRET = os.environ['SPOTIPY_CLIENT_SECRET']
# SPOTIPY_REDIRECT_URI = os.environ['SPOTIPY_REDIRECT_URI']
SPOTIPY_CLIENT_ID = '80aefc8b002344dcb3657dd85e5f6237'
SPOTIPY_CLIENT_SECRET = '18d5744f1f714988ab0a68b6de24a834'
SPOTIPY_REDIRECT_URI = 'https://example.com'
OAUTH_AUTHORIZE_URL = 'https://accounts.spotify.com/authorize'
OAUTH_TOKEN_URL = 'https://accounts.spotify.com/api/token'
SCOPE = 'playlist-modify-private'

authorization = SpotifyOAuth(client_id=SPOTIPY_CLIENT_ID, client_secret=SPOTIPY_CLIENT_SECRET,
                             redirect_uri=SPOTIPY_REDIRECT_URI, state=None, scope=SCOPE,
                             cache_path=None, username=None,
                             proxies=None, show_dialog=False,
                             requests_session=True, requests_timeout=None,
                             open_browser=True, cache_handler=None)


