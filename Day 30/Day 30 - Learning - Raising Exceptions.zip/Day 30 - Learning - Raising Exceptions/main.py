# Catching Exceptions
# --------------------------

# File not found error
#
# with open("a_file.txt") as file:
#     file.read()
# # --------------------------
#
# # Key Error
#
# a_dict = {"key": "value"}
# value = a_dict["non_existent_key"]
# # --------------------------
#
# # Index Error
#
# fruit_list = ["Apple", "Banana", "Orange"]
# fruit = fruit_list[3]
# # --------------------------
#
# # Type Error
# text = "abc"
# print(text+5)
# # --------------------------

# Error Handling Keywords:
# TRY - EXCEPT - ELSE - FINALLY
#
try:
    file = open("a_file.txt")
    a_dict = {"key": "value"}
    print(a_dict["key"])

except FileNotFoundError:
    file = open("a_file.txt", "w")
    file.write("something")

except KeyError as error_message:
    print(f"The key {error_message} does not exist.")

else:
    content = file.read()
    print(content)

finally:
    file.close()
    print("File was closed.")
    raise TypeError("This is an error I made up")


# # raising my own exception:
# height = float(input("Height: "))
# weight = float(input("Weight: "))
#
# if height > 3:
#     raise ValueError("Human Height should not be over 3 meters")
#
# bmi = weight / height ** 2
# print(bmi)
