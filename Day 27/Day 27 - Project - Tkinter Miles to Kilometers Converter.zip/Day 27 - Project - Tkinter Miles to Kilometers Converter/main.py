from tkinter import *


def calculate():
    miles = float(input_field.get())
    kilometers = round(miles * 1.60934, 2)
    return km_label.config(text=kilometers)


window = Tk()
window.minsize(width=300, height=100)
window.title("Miles to Kilometers Converter")
window.config(padx=20, pady=20)

# entry field
input_field = Entry(width=8, font=("Arial", 12, "normal"))
input_field.grid(column=1, row=0, padx=0, pady=10)
input_field.focus()

# text: "Miles" @ (2,0)
miles_label = Label(text="Miles", font=("Arial", 12, "normal"))
miles_label.grid(column=2, row=0, sticky="w")

# text: "is equal to" @ (0,1)
equal_to_label = Label(text="is equal to", font=("Arial", 12, "normal"))
equal_to_label.grid(column=0, row=1, padx=0, pady=10)

# text: "Kilometers" @ (2,1)
km_label = Label(text="Kilometers", font=("Arial", 12, "normal"))
km_label.grid(column=2, row=1, sticky="w")

# Button: "Calculate" @ (1,2)
calculate_button = Button(text="Calculate", command=calculate, font=("Arial", 12, "normal"))
calculate_button.grid(column=1, row=2, padx=20, pady=10)

# text: "___" @ (1,1)
km_label = Label(text="0", font=("Arial", 12, "normal"))
km_label.grid(column=1, row=1)

window.mainloop()
