from tkinter import *


# creating a window
window = Tk()
window.title("My First GUI Program")
window.minsize(width=500, height=300)

# creating a label
my_label = Label(text="I am a label", font=("Arial", 24, "italic"))
my_label.pack()

# ways to change/update properties of a created component like a label:

# treating it as a dictionary
my_label["text"] = "Hi there"

# configuring directly using .config
my_label.config(text="Meow")

# --------------------------------------

# giving button an action
def button_clicked():
    text1 = input.get()
    my_label.config(text=text1)

# creating a button
button = Button(text="Click me!", command=button_clicked)
button.pack()

# --------------------------------------

# Entry component (input)
entry = Entry(width=10)
entry.pack()

# prevents window from disappearing
window.mainloop()

# --------------------------------------

# unlimited arguments (*args)

# args type is tuple

def add(*args):
    total = 0
    for n in args:
        total += n
    return total

print(add(3, 5, 6))

# --------------------------------------

# unlimited keyword arguments (*kwargs)

# kwargs type is dictionary

def calculate(n, **kwargs):
    print(kwargs)
    # for key, value in kwargs.items():
        # print(key)
        # print(value)
        # print(kwargs["add"])
    n += kwargs["add"]
    n *= kwargs["multiply"]
    print(n)

calculate(2, add=3, multiply=5)


class Car:
    def __init__(self, **kw):
        self.make = kw.get("make")
        self.model = kw.get("model")
        self.color = kw.get("color")


my_car = Car(make="Nissan", )

print(my_car.model)

# --------------------------------------



