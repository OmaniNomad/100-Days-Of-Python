from tkinter import *


# giving button an action
def button1_clicked():
    text1 = entry.get()
    my_label.config(text=text1)


def button2_clicked():
    text2 = entry.get()
    my_label.config(text=text2)


# creating a window
window = Tk()
window.title("My First GUI Program")
window.minsize(width=500, height=300)
window.config(padx=20, pady=20)

# creating a label
my_label = Label(text="I am a label", font=("Arial", 24, "italic"))
my_label.config(text="This is a label")
# my_label.pack()
# my_label.place(x=100, y=200)
my_label.grid(column=0, row=0)
my_label.config(padx=50, pady=50)

# creating a button
button1 = Button(text="Click me!", command=button1_clicked)
button1.grid(column=1, row=1)

button2 = Button(text="This is a new button", command=button2_clicked)
button2.grid(column=2, row=0)

# Entry component (input)
entry = Entry(width=10)
entry.grid(column=3, row=2)

# prevents window from disappearing
window.mainloop()
