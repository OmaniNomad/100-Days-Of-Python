############### Blackjack Project #####################

#Difficulty Normal 😎: Use all Hints below to complete the project.
#Difficulty Hard 🤔: Use only Hints 1, 2, 3 to complete the project.
#Difficulty Extra Hard 😭: Only use Hints 1 & 2 to complete the project.
#Difficulty Expert 🤯: Only use Hint 1 to complete the project.

############### Our Blackjack House Rules #####################

## The deck is unlimited in size. 
## There are no jokers. 
## The Jack/Queen/King all count as 10.
## The the Ace can count as 11 or 1.
## Use the following list as the deck of cards:
## cards = [11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]
## The cards in the list have equal probability of being drawn.
## Cards are not removed from the deck as they are drawn.
## The dealer is the dealer.

##################### Hints #####################

#Hint 1: Go to this website and try out the Blackjack game: 
#   https://games.washingtonpost.com/games/blackjack/
#Then try out the completed Blackjack project here: 
#   http://blackjack-final.appbrewery.repl.run

#--------------------------------------------------------------------------------------

#ways to improve this code:
# deal_card(): this function will me to deal the initial cards as well as any follow up cards for anyone at the table. Especially needed if we have more players
#sum: rather than use += to count score each time a card is pulled, I could just use sum to find the total of the hand in question.
#"soft": Need to implement automated "soft" if there is an ace in the player's hand.
#Further improve on the language or UX by cutting out anything that is making the game look cluttered
#Could add emojis to improve UX
 

import random
from replit import clear
from art import logo

#functions for game scores

def scores():
  if on_split_hand:
    print(f"Your first hand's cards were: {player_hand_a}, your first hand's score was: {hand_a_score}")
    print(f"Your current hand is: {current_hand}, your current hand's score is: {current_score}\n")
  else:
    print(f"Your current hand is: {current_hand}, your current hand's score is: {current_score}\n")
  
  print(f"The dealer's first card is: {dealer_hand[0]}\n")

def final_score():
  if on_split_hand == True:
    print(f"Your first hand's cards were: {player_hand_a}, your first hand's score was: {hand_a_score}")
    print(f"Your second hand's cards were: {current_hand}, your second hand's score was: {current_score}\n")
  else:
    print(f"Your hand's cards were: {current_hand}, your hand's score was: {current_score}\n")
  
  print(f"The dealer's hand was: {dealer_hand}, the dealer's score was: {dealer_score}\n")

#game setup

cards = [11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]
new_game = True

while new_game:

  user_choice = input("Do you want to play a game of Blackjack? Type 'y' for yes or 'n' for no: ").lower()

  if user_choice == "n":
    print("Have a good day!\n")
    break

  #resetting hands, scores and required booleans
  current_hand = []
  current_score = 0
  player_hand_a = []
  hand_a_score = 0
  player_hand_b = []
  hand_b_score = 0
  dealer_hand = []
  dealer_score = 0
  card_11 = False
  initial_split = False
  user_split = False
  on_split_hand = False
  player_turn = True
  dealer_turn = True
  player_loss = False
  change_card = ""

  print(logo)

  #dealing cards to dealer; checking for two Aces and, if so, changing value of one of them
  for i in range (2):
    new_card = cards[random.randint(0,12)]
    dealer_hand.append(new_card)
    dealer_score += new_card
  if dealer_hand[0] == 11 and dealer_hand[1] == 11:
    dealer_hand[1] = 1
    dealer_score = 12

  #dealing cards to player; checking for Aces and giving option to change 11/1
  for i in range (2):
    new_card = cards[random.randint(0,12)]
    current_hand.append(new_card)
    current_score += new_card

  if current_hand[0] == 11 or current_hand[1] == 11:
    card_11 = True

  while card_11:
    scores()
    if current_hand[0] == 11:
      change_card = input("You have received an '11' for your first card. Would you like to change the card to a '1'? Type 'y' to change it or type 'n' to keep it as is: ").lower()
      if change_card == 'y':
        current_hand[0] = 1
        current_score -= 10
        break
      elif change_card == 'n':
        break
      else:
        print("invalid input.")
        
    elif current_hand[1] == 11:
      change_card = input("You have received an '11' for your second card. Would you like to change the card to a '1'? Type 'y' to change it or type 'n' to keep it as is: ").lower()
      if change_card == 'y':
        current_hand[1] = 1
        current_score -= 10
        break
      elif change_card == 'n':
        break
      else:
        print("invalid input.")

    elif current_hand[0] == 11 and current_hand[1] == 11:
      change_card = input("You have received two '11' cards. Type 'split' to split the cards, or type 'change' to change one of the cards to a '1': ").lower()
      if change_card == 'change':
        current_hand[1] = 1
        current_score -= 10
        break
      elif change_card == 'split':
        break
      else:
        print("invalid input.")

  #split condition
  if current_hand[0] == current_hand[1]:
    initial_split = True
  while initial_split:
    if current_hand[0] == 11 and current_hand[1] == 11:
      wants_split = "y"
    else:
      scores()
      wants_split = input("As your cards are identical, you are able to split them into two separate hands. Do you want to split your cards? Answer 'y' if yes or 'n' if no: ").lower()
    if wants_split == "y":
      user_split = True
      player_hand_a.append(current_hand[0])
      player_hand_b.append(current_hand[1])
      hand_a_score = current_hand[0]
      hand_b_score = current_hand[1]
      current_hand = player_hand_a 
      current_score = hand_a_score
      break
    elif wants_split == "n":
      break
    else:
      print("Invalid input.")

  #blackjack conditions for starting hands
  if current_score == 21 and dealer_score == 21:
    final_score()
    print("Both you and the dealer have hit Blackjack! This round is a tie.\n")
    player_turn = False
    continue

  elif current_score == 21:
    final_score()
    print("You hit Blackjack! You win the game!\n")
    player_turn = False
    continue

  elif dealer_score == 21:
    final_score()
    print("Dealer hit Blackjack! You lose the game.\n")
    player_turn = False
    continue

  #player's turn: 'stand' or 'hit'
  while player_turn:
    scores() 

    user_input = input("\nType 'hit' to get another card, type 'stand' to stop receiving cards: ").lower()

    if user_input == 'hit':
      new_card = cards[random.randint(0,12)]
      current_hand.append(new_card)
      current_score += new_card
      
      if current_score > 21:
        
        if user_split == False:
          print(f"Your hand has busted. You lose the game.\n")
          player_loss = True
          break
  
        elif user_split == True and on_split_hand == False:
          print(f"Your current score for this hand is {current_score} and your hand has busted. You can now play your split hand.\n")
          on_split_hand = True
          player_hand_a = current_hand
          hand_a_score = current_score
          current_hand = player_hand_b
          current_score = hand_b_score
  
        elif user_split == True and on_split_hand == True:
          print(f"Your hand has busted.\n")
          player_hand_b = current_hand
          hand_b_score = current_score
          if hand_a_score > 21:
            player_loss = True
            print("You lose the game.")
          break

    elif user_input == 'stand':
      if user_split == True and on_split_hand == False:
        on_split_hand = True
        player_hand_a = current_hand
        hand_a_score = current_score
        current_hand = player_hand_b
        current_score = hand_b_score
        print(f"\nYou stand this hand with a score of {hand_a_score}. You may now play your split hand.\n")
      elif user_split == True and on_split_hand == True:
        player_hand_b = current_hand
        hand_b_score = current_score
        print(f"\nYou stand this hand with a score of {hand_b_score}. It is now the dealer's turn.\n")
        break
      else:
        print(f"\nYou stand this hand with a score of {current_score}. It is now the dealer's turn.\n")
        break

    else:
      print("That input is invalid. Please try again.\n")

  while dealer_turn:
    if player_loss:
      final_score()
      break

    while dealer_score < 17:
      new_card = cards[random.randint(0,12)]
      dealer_hand.append(new_card)
      dealer_score += new_card

    final_score()
    if dealer_score > 21:
      print(f"The dealer has busted their hand. You win the game!\n")

    elif user_split == False:
      if dealer_score < current_score:
        print(f"You have a higher score. You win the game.\n")
      elif dealer_score == current_score:
        print(f"The game is a draw.\n")
      else:
        print(f"The dealer has a higher score. You lose the game.\n")
    else:
      if hand_a_score <= 21 and hand_b_score <= 21:
        if dealer_score < hand_a_score or dealer_score < hand_b_score:
          print(f"You have a higher score. You win the game.\n")
        elif dealer_score == hand_a_score and dealer_score == hand_b_score:
          print(f"The game is a draw.\n")
        else:
          print(f"The dealer has a higher score. You lose the game.\n")

      elif hand_a_score <= 21:
        if dealer_score < hand_a_score:
          print(f"You have a higher score. You win the game.\n")
        elif dealer_score == hand_a_score:
          print(f"The game is a draw.\n")
        else:
          print(f"The dealer has a higher score. You lose the game.\n")

      elif hand_b_score <= 21:
        if dealer_score < hand_b_score:
          print(f"You have a higher score. You win the game.\n")
        elif dealer_score == hand_b_score:
          print(f"The game is a draw.\n")
        else:
          print(f"The dealer has a higher score. You lose the game.\n")
    break