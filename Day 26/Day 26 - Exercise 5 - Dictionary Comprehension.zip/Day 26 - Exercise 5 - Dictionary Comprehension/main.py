# dictionary_comprehension = {new_key:new_value for item in list if test}
# import random
#
# names = ["Alex", "Beth", "Caroline", "Dave", "Eleanor", "Freddie", ]
#
# students_scores = {student: random.randint(1, 100) for student in names}
#
# passed_students = {student: score for (student, score) in students_scores.items() if score >= 70}
#
# print(students_scores)
# print(passed_students)

# -----------------------------------------------

sentence = "What is the Airspeed Velocity of an Unladen Swallow?"

result = {word:len(word) for word in sentence.split()}

print(result)
