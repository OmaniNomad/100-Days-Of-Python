# list comprehension =>  new_list = [new_item for item in list]
# ----------------------------------------------
# Adding 1 to each number in a list

# numbers = [1, 2, 3]
# new_numbers = [n + 1 for n in numbers]
# print(new_numbers)

# ----------------------------------------------

# Breaking up a name into individual letters

# name = "Yousef"
# letters_in_name = [letter for letter in name]
# print(letters_in_name)

# ----------------------------------------------

# Doubling numbers in a range

# double_numbers = [n*2 for n in range(1, 5)]
# print(double_numbers)

# ----------------------------------------------

# conditional list comprehension =>  new_list = [new_item for item in list if test]

# names = ["Alex", "Beth", "Caroline", "Eleanor", "Freddie"]
# short_names = [name for name in names if len(name) < 5]
# print(short_names)

# ----------------------------------------------

# names = ["Alex", "Beth", "Caroline", "Eleanor", "Freddie"]
# long_names = [name.upper() for name in names if len(name) > 5]
# print(long_names)
