# list comprehension =>  new_list = [new_item for item in list]

numbers = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55]

even_numbers = [number for number in numbers if number % 2 == 0]

print(even_numbers)
