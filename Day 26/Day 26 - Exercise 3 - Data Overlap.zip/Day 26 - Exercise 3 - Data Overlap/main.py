# list comprehension =>  new_list = [new_item for item in list]

with open("file1.txt", mode="r") as file:
    file1 = [int(num.strip()) for num in file]

with open("file2.txt", mode="r") as file:
    file2 = [int(num.strip()) for num in file]

result = [num for num in file1 if num in file2]

print(result)
