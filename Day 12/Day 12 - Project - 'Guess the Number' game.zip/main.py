#Number Guessing Game Objectives:

# Include an ASCII art logo.
# Allow the player to submit a guess for a number between 1 and 100.
# Check user's guess against actual answer. Print "Too high." or "Too low." depending on the user's answer. 
# If they got the answer correct, show the actual answer to the player.
# Track the number of turns remaining.
# If they run out of turns, provide feedback to the player. 
# Include two different difficulty levels (e.g., 10 guesses in easy mode, only 5 guesses in hard mode).

import random
from replit import clear
from art import logo

EASY_LVL = 5
HARD_LVL = 10

def play_game():
  print(logo)
  print("Welcome to the number guessing game!\nI'm thinking of a number between 1 and 100.")
  random_number = random.randint(1,100)
  #print(f"For testing: the number is {random_number}.")

  difficulty = input("Choose a difficulty. Type 'easy' or 'hard': ").lower()

  if difficulty == "easy":
    attempts_remaining = HARD_LVL
  else:
    attempts_remaining = EASY_LVL

  while attempts_remaining != 0:

    print(f"You have {attempts_remaining} attempts remaining to guess the number.")
    user_guess = int(input("Make a guess: "))

    if user_guess < 1 or user_guess > 100:
      print("Please choose a number between 1-100.\n")
    else:
      if user_guess == random_number:
        print("You guessed the number correctly! Congratulations!\n")
        break
      elif user_guess > random_number:
        print("Too High.")
      else:
        print("Too low.")
      
      attempts_remaining -= 1
      
      if attempts_remaining == 0:
        print(f"You've run out of guesses, you lose.\nThe number was {random_number}.\n")
        break
      else:
        print("Guess again.\n")

while input("Do you want to play the guessing game? Enter 'y' for yes and 'n' for no: ") == "y":
  clear()
  play_game()