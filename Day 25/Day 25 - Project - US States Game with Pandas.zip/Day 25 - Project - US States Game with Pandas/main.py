import turtle
import pandas
from write_on_screen import Write

# Creating screen from image
screen = turtle.Screen()
screen.title("U.S. States Game")
image = "./blank_states_img.gif"
screen.addshape(image)
turtle.shape(image)
write = Write()

# Using Pandas to read CSV and create list of all states
data = pandas.read_csv("50_states.csv")
all_states = data.state.to_list()

# Starting game
game_is_on = True
guessed_states = []
correct_states = 0
remaining_states = []

while game_is_on:
    user_answer = screen.textinput(title=f"{correct_states}/50 States Correct", prompt="What's another state name?")
    current_state = user_answer.title()

    # user can quit the game and get remaining states in txt file
    if current_state == "Quit":
        for state in all_states:
            if state not in guessed_states:
                remaining_states.append(state)
        learn_data = pandas.DataFrame(remaining_states)
        learn_data.to_csv("states_to_learn.csv")
        game_is_on = False
        write.quit(correct_states)
        break

    if current_state in all_states:
        # checking if state was already guessed
        if current_state in guessed_states:
            pass
        else:
            state_data = data[data.state == current_state]
            print(state_data)
            coordinates = (int(state_data.x), int(state_data.y))
            write.position(coordinates, current_state)
            correct_states += 1
            guessed_states.append(current_state)

    # game end if all states are guessed
    if correct_states == 50:
        game_is_on = False
        write.congrats()

screen.exitonclick()
