from turtle import Turtle
ALIGNMENT = "Center"
STATE_FONT = ('Arial', 8, 'normal')
FONT = ('Arial', 20, 'normal')


class Write(Turtle):
    def __init__(self):
        super().__init__()
        self.hideturtle()
        self.penup()

    def position(self, xy, state):
        self.goto(xy)
        self.pendown()
        self.write(arg=f"{state}", align=ALIGNMENT, font=STATE_FONT)
        self.penup()

    def quit(self, states):
        self.goto(0, 0)
        self.pendown()
        self.write(arg=f"Done already? You've managed to guess {states}/50 STATES!", align=ALIGNMENT, font=FONT)
        self.penup()

    def congrats(self):
        self.goto(0, 0)
        self.pendown()
        self.write(arg=f"CONGRATULATIONS! YOU GUESSED ALL 50 STATES!", align=ALIGNMENT, font=FONT)
        self.penup()
