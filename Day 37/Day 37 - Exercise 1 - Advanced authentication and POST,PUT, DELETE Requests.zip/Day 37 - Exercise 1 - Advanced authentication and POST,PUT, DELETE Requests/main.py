# Types of HTTP Requests
# ---------------------- #

# ---- requests.get ---- #
# asking an external system for a piece of data and receiving it in a response (ex: requesting weather
# data using openweathermap api)


# ---- requests.post ---- #
# giving an external system a piece of data without a need for response other than if it was successful
# or not. (ex: using Twitter api to post a tweet)


# ---- requests.put ---- #
# update a piece of data in an external system (ex: updating values in an existing sheet using google
# sheets api)


# ---- requests.delete ---- #
# delete a piece of data in an external system (ex: deleting a facebook post using the facebook api)

