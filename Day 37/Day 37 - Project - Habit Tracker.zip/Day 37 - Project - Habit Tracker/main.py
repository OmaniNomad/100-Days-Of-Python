import requests
import datetime as dt

PIXELA_ENDPOINT = "https://pixe.la/v1/users"
USERNAME = "ysalalawi"
TOKEN = "fighter1q1"
headers = {
"X-USER-TOKEN": TOKEN
}

# -----------------------------
# Creating an account on pixela
# -----------------------------
#
# parameters = {
#     "token": TOKEN,
#     "username": USERNAME,
#     "agreeTermsOfService": "yes",
#     "notMinor": "yes"
# }
#
# response = requests.post(url=PIXELA_ENDPOINT, json=parameters)
# print(response.text)

# ------------------------------
# Creating a graph on my account
# ------------------------------

# graph_endpoint = f"{PIXELA_ENDPOINT}/{USERNAME}/graphs"
#
#
# graph_parameters = {
#     "id": "graph1",
#     "name": "Coding Graph",
#     "unit": "Hours",
#     "type": "int",
#     "color": "ajisai",
#     "timezone": "Asia/Muscat",
# }
#
# graph = requests.post(url=graph_endpoint, json=graph_parameters, headers=headers)
# print(graph.text)

# ------------------------------
# Posting a pixel on the graph
# ------------------------------
# today = dt.datetime.now()
# # specific_day = dt.datetime(year=2022, month=1, day=29)
#
# graph_id = "graph1"
#
# pixel_parameters = {
#     "date": today.strftime("%Y%m%d"),
#     "quantity": "6"
# }
#
# pixel_endpoint = f"{PIXELA_ENDPOINT}/{USERNAME}/graphs/{graph_id}"
#
# pixel = requests.post(url=pixel_endpoint, json=pixel_parameters, headers=headers)
# print(pixel.text)

# ------------------------------
# Update a pixel on the graph
# ------------------------------
# today = dt.datetime.now()
# # specific_day = dt.datetime(year=2022, month=1, day=29)
# date = today.strftime("%Y%m%d")
#
# graph_id = "graph1"
#
# pixel_parameters = {
#     "quantity": input("How many hours did you spend programming today?")
# }
#
# pixel_endpoint = f"{PIXELA_ENDPOINT}/{USERNAME}/graphs/{graph_id}/{date}"
#
# pixel = requests.put(url=pixel_endpoint, json=pixel_parameters, headers=headers)
# print(pixel.text)

# ------------------------------
# Delete a pixel on the graph
# ------------------------------
# today = dt.datetime.now()
# # specific_day = dt.datetime(year=2022, month=1, day=29)
# date = today.strftime("%Y%m%d")
#
# graph_id = "graph1"
#
# pixel_endpoint = f"{PIXELA_ENDPOINT}/{USERNAME}/graphs/{graph_id}/{date}"
#
# pixel = requests.delete(url=pixel_endpoint, headers=headers)
# print(pixel.text)
