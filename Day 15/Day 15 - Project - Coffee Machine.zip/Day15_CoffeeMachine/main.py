from extras import MENU, resources, COINS

check = ""
machine_on = True
piggy_bank = 0


def show_resources():
    print(f'Water: {resources["water"]}ml\nMilk: {resources["milk"]}ml\nCoffee: {resources["coffee"]}g\nMoney: ${piggy_bank}')


def check_resources(coffee_type):
    if resources["water"] >= MENU[coffee_type]["ingredients"]["water"]:
        if resources["milk"] >= MENU[coffee_type]["ingredients"]["milk"]:
            if resources["coffee"] >= MENU[coffee_type]["ingredients"]["coffee"]:
                return True
            else:
                return "coffee"
        else:
            return "milk"
    else:
        return "water"


def process_coins(coffee_type):
    print("Please insert coins.")
    quarters = int(input("How many quarters?: "))
    dimes = int(input("How many dimes?: "))
    nickels = int(input("How many nickels?: "))
    pennies = int(input("How many pennies?: "))

    total_coins = quarters*COINS["quarter"] + dimes*COINS["dime"] + nickels*COINS["nickel"] + pennies*COINS["penny"]
    cost = MENU[coffee_type]["cost"]

    if total_coins >= cost:
        if total_coins > cost:
            change = round(total_coins - cost, 2)
            print(f"Here is ${change} in change.")
        return True


def make_coffee(coffee_type):
    print(f"Here is your {coffee_type} ☕. Enjoy")
    resources["water"] -= MENU[coffee_type]["ingredients"]["water"]
    resources["milk"] -= MENU[coffee_type]["ingredients"]["milk"]
    resources["coffee"] -= MENU[coffee_type]["ingredients"]["coffee"]


while machine_on:
    user_request = input("What would you like? (espresso/latte/cappuccino): ").lower()
    # User chooses the type of coffee or enters secret codes: report/off
    if user_request == "off":
        print("Machine turning off.")
        break

    elif user_request == "report":
        show_resources()
        # prints report of remaining resources and money

    elif user_request == "espresso" or user_request == "latte" or user_request == "cappuccino":
        check = check_resources(user_request)
        if check:
            # checks if the machine has enough resources for the requested type
            if process_coins(user_request):
                # checks coins and takes them if enough. Returns change. Stores cost in bank.
                piggy_bank += MENU[user_request]["cost"]
                make_coffee(user_request)
                # Tells user coffee is made, takes resources needed for drink
            else:
                print("Sorry, that's not enough money. Money Refunded.")
        else:
            print(f"Sorry, there is not enough {check}")
    else:
        print("Invalid input.")