import random
from replit import clear
from art import logo, vs
from game_data import data

example_b = ""
score = 0
play_game = True

#chooses an example for the new round
def new_example():
  choice = random.choice(data)
  while example_b != "" and choice["follower_count"] == b_followers:
     choice = random.choice(data)
  followers = choice["follower_count"]
  example = f'{choice["name"]}, a {choice["description"]}, from {choice["country"]}.'
  return [followers, example]

def check_answer(user_score):
  if user_choice == "a":
    if a_followers > b_followers:
      user_score += 1
      print(f"You're right! Current score: {user_score}\n")
      return user_score
    else:
      print(f"Sorry, that's wrong. Final score: {score}\n")
      return 0
  else:
    if b_followers > a_followers:
      user_score += 1
      print(f"You're right! Current score: {user_score}\n")
      return user_score
    else:
      print(f"Sorry, that's wrong. Final score: {user_score}\n")
      return 0

while play_game:
  user_choice = ""
  print(logo)
  print(f"Score: {score}")
  #This will call a new example for first round, while for follow up questions, previous example B becomes example A.
  if example_b != "":
    print(f"\nCompare A: {example_b[1]}\n")
    a_followers = b_followers
  else:
    example_a = new_example() #new_example() returns a list
    a_followers = example_a[0]
    print(f"\nCompare A: {example_a[1]}\n")

  print(vs)

  example_b = new_example()
  b_followers = example_b[0]
  print(f"\nAgainst B: {example_b[1]}\n")

  while user_choice != "a" and user_choice != "b":
    user_choice = input("Who has more followers? Type 'a'  or 'b': ").lower()

  result = check_answer(score)
  if result == 0:
    score = 0
    break
  else:
    score += 1
    clear()
          

